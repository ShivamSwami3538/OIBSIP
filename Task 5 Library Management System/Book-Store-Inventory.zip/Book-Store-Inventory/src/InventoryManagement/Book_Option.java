package InventoryManagement;

public class Book_Option {
	public static final int ADD_BOOK = 1;
	public static final int UPDATE_BOOK = 2;
	public static final int SEARCH_BOOK = 3;
	public static final int DELETE_BOOK = 4;
	public static final int PURCHASE_BOOK = 5;
	public static final int EXIT = 6;
}
