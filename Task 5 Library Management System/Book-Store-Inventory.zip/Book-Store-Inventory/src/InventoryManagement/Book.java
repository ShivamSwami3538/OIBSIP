package InventoryManagement;

public class Book {
	String Book_Title;
	String Book_ISBN;
	String Author_Name;
	String Quantity;
	String Price;
}
