package UserManagement;

public class User {
	String Username;
	String LoginName;
	String Password;
	String UserID;
}
