package UserManagement;

public class User_Option {
	public static final int ADD_USER = 1;
	public static final int EDIT_USER = 2;
	public static final int DELETE_USER = 3;
	public static final int SEARCH_USER = 4;
	public static final int QUIT = 5;
}
